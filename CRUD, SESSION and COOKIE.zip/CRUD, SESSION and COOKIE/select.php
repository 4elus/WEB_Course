<?php
    if (isset($_POST['submit'])){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $connection = mysqli_connect("localhost", "root", "", "first_db");

        $query = "SELECT * FROM users;";

        if ($connection){
            $query_result = mysqli_query($connection, $query);
            if ($query_result){
                $data_array = mysqli_fetch_array($query_result);
                echo "Hello, " . $data_array['username'] . " Email: " . $data_array['email'];
            }
        } else{
            die("Connection denied");
        }
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>SQL</title>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Form</h1>
        <form method="post" action="index.php">
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" name="password" id="exampleInputPassword1">
            </div>
            <button type="submit" name="submit" class="btn btn-primary float-right">log in</button>
        </form>
    </div>
</body>
</html>