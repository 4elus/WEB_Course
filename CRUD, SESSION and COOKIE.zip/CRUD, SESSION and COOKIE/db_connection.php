<?php
$connection = mysqli_connect("localhost", "root", "", "my_first_db");

if (!$connection){
    die ("Denied");
}
?>
