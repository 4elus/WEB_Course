<?php

?>

<form action="action.php" method="post">
    <input type="text" name="username" placeholder="name">
    <input type="password" name="password" placeholder="password">
    <input type="submit">
</form>
