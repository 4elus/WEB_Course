<?php

    $store = array(
        "Alex" => "1234",
        "Sam" => "789"
    );

    $login = $_POST["username"];
    $password = $_POST["password"];

    $isLogin = false;

    foreach ($store as $key => $value){
        if ($key == $login && $value == $password){
            $isLogin = true;
        }
    }

    if ($isLogin){
        echo "Hello, " . $login;
    }else{
        echo "Error";
    }

?>
