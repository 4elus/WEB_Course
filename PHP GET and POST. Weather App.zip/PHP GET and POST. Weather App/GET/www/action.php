<?php
//if(isset($_GET))
    $login = $_GET["username"];
    $password = $_GET["password"];

    echo "Your login - " . $login;
    echo "<br>Your password - " . $password;
?>
